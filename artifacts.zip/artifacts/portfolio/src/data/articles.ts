export type Article = {
  id: number;
  slug: string;
  title: string;
  excerpt: string;
  date: string;
  readTime: string;
  tags: string[];
  content: string;
};

export const articles: Article[] = [
  {
    id: 1,
    slug: "python-en-premier",
    title: "Pourquoi j'ai appris Python en premier — et pourquoi c'était la bonne décision",
    excerpt: "Python m'a appris à penser comme un programmeur avant de penser comme un ingénieur...",
    date: "12 juin 2025",
    readTime: "5 min",
    tags: ["Python", "Apprentissage"],
    content: `Python a été mon tout premier langage de programmation. Beaucoup me déconseillaient de commencer par là, préférant que j'apprenne directement le JavaScript ou même le C. Mais aujourd'hui, je suis convaincu que c'était le bon choix.

La syntaxe épurée de Python m'a permis de me concentrer sur les concepts fondamentaux : les variables, les boucles, les fonctions, la logique — sans me perdre dans des accolades ou des points-virgules. Mes premiers scripts étaient simples : un calculateur, un jeu de devinettes, un convertisseur de températures.

Ce qui m'a le plus marqué, c'est que Python m'a appris à décomposer un problème avant d'écrire la moindre ligne de code. C'est une habitude que j'applique encore aujourd'hui, quel que soit le langage. Si tu hésites encore sur ton premier langage, mon conseil : commence par Python. Tu pourras toujours apprendre les autres ensuite — et tu les comprendras beaucoup mieux.`,
  },
  {
    id: 2,
    slug: "react-vs-vanilla-js",
    title: "React vs Vanilla JS : ce que j'ai compris après avoir construit les deux",
    excerpt: "Après avoir construit une app de suivi de films en Vanilla JS puis en React...",
    date: "3 mai 2025",
    readTime: "7 min",
    tags: ["React", "JavaScript", "Web Dev"],
    content: `Quand j'ai commencé à apprendre le développement web, tout le monde me parlait de React. Mais avant d'y toucher, j'ai voulu comprendre les fondations : j'ai construit une app de suivi de films entièrement en Vanilla JavaScript.

C'était instructif — et franchement douloureux. Gérer le DOM manuellement, synchroniser l'état avec l'interface, éviter les bugs de re-rendu... J'ai vite compris pourquoi les frameworks existent. Quand j'ai refait la même app en React, la différence était frappante : le code était plus court, plus lisible, et beaucoup plus facile à faire évoluer.

Cela dit, je ne regrette pas d'avoir commencé par le Vanilla JS. Comprendre ce que React fait "sous le capot" m'a rendu bien meilleur développeur React. Si tu débutes, je te recommande de faire les deux : quelques semaines de Vanilla JS pour les bases, puis plonger dans React. Tu seras bien mieux armé.`,
  },
  {
    id: 3,
    slug: "git-pour-debutants",
    title: "Git pour les débutants : les commandes que j'aurais voulu connaître dès le début",
    excerpt: "Je me souviens encore de la première fois où j'ai cassé un repo...",
    date: "18 mars 2025",
    readTime: "6 min",
    tags: ["Git", "Outils", "Débutant"],
    content: `La première fois que j'ai utilisé Git, j'ai fait un \`git push --force\` sur la mauvaise branche et perdu deux jours de travail. Personne ne m'avait dit que c'était dangereux. Voici ce que j'aurais voulu savoir dès le début.

Les commandes essentielles : \`git init\`, \`git add .\`, \`git commit -m "message"\`, \`git push\`, \`git pull\`. Jusque-là, simple. Mais les vrais gains de productivité viennent des branches : créer une branche avec \`git checkout -b ma-feature\`, travailler dessus, puis merger avec \`git merge\` ou faire une pull request.

Ce que j'évite maintenant : \`git push --force\` (sauf si je sais exactement ce que je fais), travailler directement sur \`main\`, et ignorer les messages d'erreur de Git. Git est ton meilleur ami si tu l'écoutes. Prends le temps de lire ses messages — ils sont souvent plus utiles qu'ils n'en ont l'air.`,
  },
];
