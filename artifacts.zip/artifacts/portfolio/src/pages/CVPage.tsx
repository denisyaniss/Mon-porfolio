import { useEffect } from "react";
import { Link } from "wouter";
import { ArrowLeft, Printer } from "lucide-react";

export default function CVPage() {
  useEffect(() => {
    document.title = "CV — Denis Yaniss";
  }, []);

  return (
    <div className="min-h-screen bg-white text-gray-900 font-sans">

      {/* Barre d'actions (masquée à l'impression) */}
      <div className="print:hidden flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-white sticky top-0 z-10">
        <Link href="/" className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Retour au portfolio
        </Link>
        <button
          onClick={() => window.print()}
          data-testid="button-print-cv"
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium bg-gray-900 text-white rounded-md hover:bg-gray-700 transition-colors"
        >
          <Printer className="w-4 h-4" />
          Imprimer / Exporter PDF
        </button>
      </div>

      {/* Corps du CV */}
      <div className="max-w-3xl mx-auto px-8 py-12 print:py-6 print:px-0">

        {/* En-tête */}
        <header className="border-b-2 border-gray-900 pb-6 mb-8">
          <h1 className="text-4xl font-extrabold tracking-tight text-gray-900 mb-1">
            Denis Yaniss
          </h1>
          <p className="text-lg font-medium text-teal-700 mb-3">
            Étudiant Développeur — Université Don Bosco de Lubumbashi
          </p>
          <div className="flex flex-wrap gap-x-6 gap-y-1 text-sm text-gray-600">
            <span>Lubumbashi, RD Congo</span>
            <a href="mailto:denisyaniss@email.com" className="hover:text-teal-700">officialdenis304@gmail.com</a>
            <a href="https://github.com/denisyaniss" className="hover:text-teal-700">https://github.com/denisyaniss</a>
            <a href="https://linkedin.com/in/denisyaniss" className="hover:text-teal-700">https://www.linkedin.com/in/denis-yaniss-baa0aa3a6?utm_source=share_via&utm_content=profile&utm_medium=member_android</a>
          </div>
        </header>

        {/* Profil */}
        <section className="mb-8">
          <h2 className="text-xs font-bold tracking-widest uppercase text-teal-700 mb-3 border-b border-gray-200 pb-1">
            Profil
          </h2>
          <p className="text-sm leading-relaxed text-gray-700">
            Étudiant passionné de programmation et de technologies numériques à l'Université Don Bosco de Lubumbashi. 
            Curieux, autodidacte et rigoureux, je construis des projets web et des outils en Python pour résoudre des problèmes concrets. 
            Je cherche à appliquer mes compétences techniques dans un environnement professionnel stimulant.
          </p>
        </section>

        {/* Formation */}
        <section className="mb-8">
          <h2 className="text-xs font-bold tracking-widest uppercase text-teal-700 mb-3 border-b border-gray-200 pb-1">
            Formation
          </h2>
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-sm font-semibold text-gray-900">Université Don Bosco de Lubumbashi</h3>
              <p className="text-sm text-gray-600">Informatique / Génie Logiciel</p>
            </div>
            <span className="text-sm text-gray-500 whitespace-nowrap">En cours</span>
          </div>
        </section>

        {/* Compétences techniques */}
        <section className="mb-8">
          <h2 className="text-xs font-bold tracking-widest uppercase text-teal-700 mb-3 border-b border-gray-200 pb-1">
            Compétences techniques
          </h2>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <h3 className="font-semibold text-gray-800 mb-1">Langages</h3>
              <p className="text-gray-600">Python, C, Java JavaScript, TypeScript, HTML, CSS</p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-800 mb-1">Frameworks & Bibliothèques</h3>
              <p className="text-gray-600">React, Node.js, Tailwind CSS</p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-800 mb-1">Outils</h3>
              <p className="text-gray-600">Git, GitHub, VS Code, Linux</p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-800 mb-1">En apprentissage</h3>
              <p className="text-gray-600">Python avancé, TypeScript avancé, SQL, Sécurité informatique</p>
            </div>
          </div>
        </section>

        {/* Projets */}
        <section className="mb-8">
          <h2 className="text-xs font-bold tracking-widest uppercase text-teal-700 mb-3 border-b border-gray-200 pb-1">
            Projets
          </h2>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-start">
                <h3 className="text-sm font-semibold text-gray-900">Gestionnaire de dépenses personnel</h3>
                <span className="text-xs text-gray-500">React, TypeScript</span>
              </div>
              <p className="text-sm text-gray-600 mt-0.5">
                Application web pour suivre ses dépenses quotidiennes, générer des graphiques et exporter les données en CSV.
              </p>
            </div>
            <div>
              <div className="flex justify-between items-start">
                <h3 className="text-sm font-semibold text-gray-900">Outil météo en ligne de commande</h3>
                <span className="text-xs text-gray-500">Python</span>
              </div>
              <p className="text-sm text-gray-600 mt-0.5">
                Script CLI qui récupère et affiche les données météo en temps réel via une API publique, avec options de localisation.
              </p>
            </div>
            <div>
              <div className="flex justify-between items-start">
                <h3 className="text-sm font-semibold text-gray-900">Liste de films à regarder</h3>
                <span className="text-xs text-gray-500">React, JavaScript</span>
              </div>
              <p className="text-sm text-gray-600 mt-0.5">
                Application de gestion de liste de films avec recherche, filtres par genre et marquage des films vus.
              </p>
            </div>
          </div>
        </section>

        {/* Langues */}
        <section className="mb-8">
          <h2 className="text-xs font-bold tracking-widest uppercase text-teal-700 mb-3 border-b border-gray-200 pb-1">
            Langues
          </h2>
          <div className="flex gap-8 text-sm text-gray-700">
            <span><strong>Français</strong> — Courant</span>
            <span><strong>Anglais</strong> — Intermédiaire (technique)</span>
          </div>
        </section>

        {/* Centres d'intérêt */}
        <section>
          <h2 className="text-xs font-bold tracking-widest uppercase text-teal-700 mb-3 border-b border-gray-200 pb-1">
            Centres d'intérêt
          </h2>
          <p className="text-sm text-gray-600">
            Développement open-source · Sécurité informatique · Lecture tech · Veille technologique
          </p>
        </section>

      </div>

      {/* Styles impression */}
      <style>{`
        @media print {
          @page { margin: 1.5cm; }
          body { font-size: 12px; }
        }
      `}</style>
    </div>
  );
}
