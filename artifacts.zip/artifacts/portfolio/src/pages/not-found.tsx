import { motion } from "framer-motion";
import { Link } from "wouter";
import { useEffect, useState } from "react";

export default function NotFound() {
  const [dots, setDots] = useState("");

  useEffect(() => {
    const timer = setInterval(() => {
      setDots((d) => (d.length >= 3 ? "" : d + "."));
    }, 500);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="max-w-lg w-full"
      >
        <div className="bg-secondary border border-border rounded-xl p-8 font-mono text-sm shadow-xl">
          <div className="flex gap-2 mb-6">
            <div className="w-3 h-3 rounded-full bg-destructive" />
            <div className="w-3 h-3 rounded-full bg-yellow-500" />
            <div className="w-3 h-3 rounded-full bg-green-500" />
          </div>

          <div className="space-y-2 text-muted-foreground">
            <p>
              <span className="text-primary">$</span> navigate to{" "}
              <span className="text-foreground">this-page</span>
            </p>
            <p className="text-destructive">
              Error: 404 — Page not found
            </p>
            <p>
              <span className="text-primary">$</span> looking for alternatives
              <span className="text-primary">{dots}</span>
            </p>
          </div>

          <div className="mt-8 border-t border-border/50 pt-6 space-y-3">
            <p className="text-primary text-lg font-bold">404</p>
            <p className="text-foreground">Cette page n'existe pas.</p>
            <p className="text-muted-foreground text-xs">
              Peut-être une faute de frappe dans l'URL ?
            </p>
          </div>
        </div>

        <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
          <Link
            href="/"
            data-testid="link-back-home"
            className="inline-flex h-11 items-center justify-center rounded-md bg-primary px-6 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Retour à l'accueil
          </Link>
          <Link
            href="/#contact"
            data-testid="link-contact-404"
            className="inline-flex h-11 items-center justify-center rounded-md border border-border bg-transparent px-6 text-sm font-medium text-foreground transition-colors hover:bg-secondary"
          >
            Me contacter
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
