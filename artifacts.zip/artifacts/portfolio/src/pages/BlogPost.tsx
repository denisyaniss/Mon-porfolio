import { useEffect } from "react";
import { Link, useParams, useLocation } from "wouter";
import { motion } from "framer-motion";
import { ArrowLeft, Clock, Tag } from "lucide-react";
import { articles } from "@/data/articles";
import { Navbar } from "@/components/Navbar";

export default function BlogPost() {
  const params = useParams();
  const [, setLocation] = useLocation();
  const slug = params.slug;

  const article = articles.find((a) => a.slug === slug);

  useEffect(() => {
    if (!article) {
      setLocation("/");
    } else {
      window.scrollTo(0, 0);
    }
  }, [article, setLocation]);

  if (!article) return null;

  return (
    <div className="bg-background min-h-screen text-foreground selection:bg-primary selection:text-primary-foreground">
      <Navbar />
      <main className="max-w-3xl mx-auto px-6 py-32">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Link href="/#blog" className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors mb-8 text-sm font-medium">
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>

          <header className="mb-10">
            <div className="flex flex-wrap items-center gap-3 mb-4">
              <span className="flex items-center gap-1 text-sm text-muted-foreground font-mono">
                <Clock className="w-4 h-4" />
                {article.readTime}
              </span>
              <span className="text-muted-foreground/40 text-sm">·</span>
              <span className="text-sm text-muted-foreground font-mono">{article.date}</span>
            </div>

            <h1 className="text-3xl md:text-5xl font-bold tracking-tight mb-6 leading-tight">
              {article.title}
            </h1>

            <div className="flex flex-wrap gap-2">
              {article.tags.map((tag) => (
                <span
                  key={tag}
                  className="inline-flex items-center gap-1 text-sm font-mono px-3 py-1.5 rounded-full bg-primary/10 text-primary border border-primary/20"
                >
                  <Tag className="w-3 h-3" />
                  {tag}
                </span>
              ))}
            </div>
          </header>

          <div className="prose prose-neutral dark:prose-invert max-w-none prose-p:leading-relaxed prose-p:text-lg text-muted-foreground">
            {article.content.split('\n\n').map((paragraph, idx) => (
              <p key={idx} className="mb-6">{paragraph}</p>
            ))}
          </div>
        </motion.div>
      </main>
    </div>
  );
}
