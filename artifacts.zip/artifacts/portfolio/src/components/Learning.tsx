import { motion } from "framer-motion";
import { BookOpen, Monitor, Cpu } from "lucide-react";

const items = [
  {
    category: "Livres",
    icon: BookOpen,
    color: "text-amber-500",
    bg: "bg-amber-500/10 border-amber-500/20",
    list: [
      {
        title: "Clean Code",
        author: "Robert C. Martin",
        note: "Écrire un code lisible et maintenable.",
      },
      {
        title: "The Pragmatic Programmer",
        author: "Hunt & Thomas",
        note: "Les bons réflexes du développeur moderne.",
      },
    ],
  },
  {
    category: "Cours",
    icon: Monitor,
    color: "text-blue-400",
    bg: "bg-blue-400/10 border-blue-400/20",
    list: [
      {
        title: "Full-Stack Open",
        author: "Université d'Helsinki",
        note: "React, Node.js, GraphQL, TypeScript.",
      },
      {
        title: "CS50 — Introduction to Computer Science",
        author: "Harvard / edX",
        note: "Fondamentaux : algorithmique, C, Python, SQL.",
      },
    ],
  },
  {
    category: "Technologies",
    icon: Cpu,
    color: "text-primary",
    bg: "bg-primary/10 border-primary/20",
    list: [
      {
        title: "TypeScript avancé",
        author: "Génériques, utilitaires de types",
        note: "Renforcer la robustesse du code.",
      },
      {
        title: "Sécurité informatique",
        author: "OWASP, principes de base",
        note: "Comprendre les vulnérabilités web courantes.",
      },
    ],
  },
];

const containerVariants = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.12 } },
};

const cardVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
};

export function Learning() {
  return (
    <section
      id="learning"
      className="py-24 px-6 md:px-12 border-t border-border/50"
    >
      <div className="max-w-4xl mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.5 }}
          className="mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-3 font-sans flex items-center gap-4">
            <span className="text-primary font-mono text-xl md:text-2xl font-normal">
              04.
            </span>{" "}
            Ce que j'apprends en ce moment
          </h2>
          <p className="text-muted-foreground text-lg">
            Toujours en mouvement — livres ouverts, cours en cours, technologies
            explorées.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          className="grid md:grid-cols-3 gap-6"
        >
          {items.map((group) => {
            const Icon = group.icon;
            return (
              <motion.div
                key={group.category}
                variants={cardVariants}
                data-testid={`card-learning-${group.category.toLowerCase()}`}
                className="bg-secondary border border-border rounded-xl p-6 flex flex-col gap-5"
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`inline-flex items-center justify-center w-9 h-9 rounded-lg border ${group.bg}`}
                  >
                    <Icon className={`w-4 h-4 ${group.color}`} />
                  </span>
                  <h3 className="font-semibold text-foreground">
                    {group.category}
                  </h3>
                </div>

                <ul className="space-y-4">
                  {group.list.map((item) => (
                    <li key={item.title} className="flex flex-col gap-0.5">
                      <span className="text-sm font-medium text-foreground leading-snug">
                        {item.title}
                      </span>
                      <span className="text-xs font-mono text-primary/80">
                        {item.author}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {item.note}
                      </span>
                    </li>
                  ))}
                </ul>

                <div className="mt-auto pt-3 border-t border-border/50">
                  <span className="inline-flex items-center gap-1.5 text-xs font-mono text-muted-foreground">
                    <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                    En cours
                  </span>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
