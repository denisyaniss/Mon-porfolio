import { motion } from "framer-motion";

export function About() {
  return (
    <section id="about" className="py-24 px-6 md:px-12 border-t border-border/50 relative overflow-hidden">
      <div className="max-w-4xl mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-8 font-sans flex items-center gap-4">
            <span className="text-primary font-mono text-xl md:text-2xl font-normal">01.</span> About
          </h2>
          
          <div className="grid md:grid-cols-2 gap-12 items-start">
            <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
              <p>
I am Denis Yaniss, a software development student at Don Bosco University in Lubumbashi, obsessed with the space where logic meets creativity. My journey began with scripting. My initial difficulties with Python have led me to develop a deep passion that will undoubtedly change everything in my life. </p>

              <p>I enjoy learning and solving computer problems. Curiosity runs in my veins.</p>
              <p>Program | Secure | Innovate</p>
            </div>
            
            <div className="relative group">
              <div className="absolute inset-0 bg-primary/20 translate-x-4 translate-y-4 rounded-lg transition-transform group-hover:translate-x-2 group-hover:translate-y-2 z-0"></div>
              <div className="bg-secondary p-8 rounded-lg border border-border relative z-10 font-mono text-sm shadow-xl">
                <div className="flex gap-2 mb-4">
                  <div className="w-3 h-3 rounded-full bg-destructive"></div>
                  <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                </div>
                <div className="text-muted-foreground space-y-2">
                  <p><span className="text-primary">const</span> <span className="text-foreground">coder</span> = {'{'}</p>
                  <p className="pl-4">name: <span className="text-green-400">'Denis Yaniss'</span>,</p>
                  <p className="pl-4">univ: <span className="text-green-400">'Don Bosco, Lubumbashi'</span>,</p>
                  <p className="pl-4">coffeeLevel: <span className="text-orange-400">100</span>,</p>
                  <p className="pl-4">passions: [<span className="text-green-400">'Computer Engineer'</span>, <span className="text-green-400">'Tech'</span>],</p>
                  <p>{'};'}</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
