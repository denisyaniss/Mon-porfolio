import { motion } from "framer-motion";
import { Github, ExternalLink } from "lucide-react";

const projects = [
  {
    title: "SpendFlow",
    description: "A comprehensive personal expense tracker. Provides visual insights into spending habits with beautiful charts and seamless data entry.",
    stack: ["React", "TypeScript", "Tailwind CSS", "Recharts"],
    github: "https://github.com/denisyaniss",
    live: "/budget-tracker/",
  },
  {
    title: "SkyCLI",
    description: "A fast, lightweight weather CLI tool written in Python. Fetches real-time weather data and forecasts directly in your terminal.",
    stack: ["Python", "Requests", "Rich", "Click"],
    github: "https://github.com/denisyaniss",
    live: "",
  },
  {
    title: "CineTrack",
    description: "A movie watchlist application using the TMDB API. Users can search, save, and rate movies they want to watch or have seen.",
    stack: ["Next.js", "React Query", "Framer Motion", "Radix UI"],
    github: "https://github.com/denisyaniss",
    live: "#",
  }
];

export function Projects() {
  return (
    <section id="projects" className="py-24 px-6 md:px-12 border-t border-border/50">
      <div className="max-w-5xl mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.5 }}
          className="mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold font-sans flex items-center gap-4">
            <span className="text-primary font-mono text-xl md:text-2xl font-normal">03.</span> Projects
          </h2>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {projects.map((project, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="group relative flex flex-col justify-between bg-secondary/40 border border-border p-8 rounded-xl hover:-translate-y-2 transition-transform duration-300"
            >
              <div className="absolute top-0 right-0 p-8 flex gap-4 opacity-0 group-hover:opacity-100 transition-opacity">
                {project.github && (
                  <a href={project.github} className="text-muted-foreground hover:text-primary transition-colors" aria-label="GitHub">
                    <Github className="w-5 h-5" />
                  </a>
                )}
                {project.live && (
                  <a href={project.live} className="text-muted-foreground hover:text-primary transition-colors" aria-label="Live demo">
                    <ExternalLink className="w-5 h-5" />
                  </a>
                )}
              </div>
              
              <div>
                <div className="font-mono text-primary text-sm mb-4">Featured Project</div>
                <h3 className="text-2xl font-bold mb-4 text-foreground group-hover:text-primary transition-colors">{project.title}</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {project.description}
                </p>
              </div>
              
              <ul className="flex flex-wrap gap-3 font-mono text-xs text-muted-foreground mt-auto">
                {project.stack.map((tech, tIdx) => (
                  <li key={tIdx} className="bg-background/50 px-2 py-1 rounded border border-border/50">{tech}</li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
