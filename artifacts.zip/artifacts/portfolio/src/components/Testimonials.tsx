import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Quote, PlusCircle, X, CheckCircle } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetTestimonials,
  useCreateTestimonial,
  getGetTestimonialsQueryKey,
} from "@workspace/api-client-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

const schema = z.object({
  name: z.string().min(2, "Au moins 2 caractères"),
  role: z.string().min(2, "Au moins 2 caractères"),
  school: z.string().min(2, "Au moins 2 caractères"),
  text: z.string().min(10, "Au moins 10 caractères"),
});
type FormData = z.infer<typeof schema>;

const containerVariants = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.14 } },
};
const cardVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
};

export function Testimonials() {
  const [showForm, setShowForm] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const queryClient = useQueryClient();

  const { data: testimonials = [], isLoading } = useGetTestimonials();
  const createMutation = useCreateTestimonial({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetTestimonialsQueryKey() });
        setSubmitted(true);
        setShowForm(false);
        reset();
        setTimeout(() => setSubmitted(false), 5000);
      },
    },
  });

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormData>({ resolver: zodResolver(schema) });

  const onSubmit = (data: FormData) => {
    createMutation.mutate({ data });
  };

  return (
    <section id="testimonials" className="py-24 px-6 md:px-12 border-t border-border/50">
      <div className="max-w-4xl mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.5 }}
          className="mb-12 flex flex-col sm:flex-row sm:items-end justify-between gap-4"
        >
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-3 font-sans flex items-center gap-4">
              <span className="text-primary font-mono text-xl md:text-2xl font-normal">06.</span>
              Témoignages
            </h2>
            <p className="text-muted-foreground text-lg">
              Ce que disent ceux qui m'ont côtoyé et accompagné.
            </p>
          </div>
          <button
            onClick={() => { setShowForm(true); setSubmitted(false); }}
            data-testid="button-add-testimonial"
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-mono border border-primary/50 text-primary rounded-md hover:bg-primary/10 transition-colors whitespace-nowrap self-start sm:self-auto"
          >
            <PlusCircle className="w-4 h-4" />
            Laisser un témoignage
          </button>
        </motion.div>

        {/* Formulaire d'ajout */}
        <AnimatePresence>
          {showForm && (
            <motion.div
              initial={{ opacity: 0, y: -16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.3 }}
              className="mb-10 bg-secondary border border-primary/30 rounded-xl p-6 relative"
            >
              <button
                onClick={() => setShowForm(false)}
                data-testid="button-close-form"
                className="absolute top-4 right-4 text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
              <h3 className="font-semibold text-foreground mb-5 text-lg">
                Ajouter votre témoignage
              </h3>
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <Input
                      {...register("name")}
                      placeholder="Votre nom"
                      data-testid="input-testimonial-name"
                      className="bg-background"
                    />
                    {errors.name && (
                      <p className="text-xs text-destructive mt-1">{errors.name.message}</p>
                    )}
                  </div>
                  <div>
                    <Input
                      {...register("role")}
                      placeholder="Votre rôle (ex: Professeur, Camarade)"
                      data-testid="input-testimonial-role"
                      className="bg-background"
                    />
                    {errors.role && (
                      <p className="text-xs text-destructive mt-1">{errors.role.message}</p>
                    )}
                  </div>
                </div>
                <div>
                  <Input
                    {...register("school")}
                    placeholder="Votre institution ou université"
                    data-testid="input-testimonial-school"
                    className="bg-background"
                  />
                  {errors.school && (
                    <p className="text-xs text-destructive mt-1">{errors.school.message}</p>
                  )}
                </div>
                <div>
                  <Textarea
                    {...register("text")}
                    placeholder="Écrivez votre témoignage sur Denis Yaniss..."
                    data-testid="input-testimonial-text"
                    rows={4}
                    className="bg-background resize-none"
                  />
                  {errors.text && (
                    <p className="text-xs text-destructive mt-1">{errors.text.message}</p>
                  )}
                </div>
                <button
                  type="submit"
                  data-testid="button-submit-testimonial"
                  disabled={createMutation.isPending}
                  className="inline-flex h-10 items-center justify-center rounded-md bg-primary px-6 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-60 disabled:pointer-events-none"
                >
                  {createMutation.isPending ? "Envoi..." : "Publier le témoignage"}
                </button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Message de succès */}
        <AnimatePresence>
          {submitted && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mb-8 flex items-center gap-3 text-sm text-green-500 bg-green-500/10 border border-green-500/20 rounded-lg px-4 py-3"
            >
              <CheckCircle className="w-4 h-4 flex-shrink-0" />
              Merci ! Votre témoignage a été publié et apparaît maintenant sur le portfolio.
            </motion.div>
          )}
        </AnimatePresence>

        {/* Liste des témoignages */}
        {isLoading ? (
          <div className="grid md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-secondary border border-border rounded-xl p-6 animate-pulse h-48" />
            ))}
          </div>
        ) : testimonials.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground text-sm font-mono">
            <p>Aucun témoignage pour l'instant.</p>
            <p className="mt-1 text-xs">Soyez le premier à en laisser un !</p>
          </div>
        ) : (
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            className="grid md:grid-cols-3 gap-6"
          >
            {testimonials.map((t) => (
              <motion.div
                key={t.id}
                variants={cardVariants}
                data-testid={`card-testimonial-${t.id}`}
                className="group relative bg-secondary border border-border rounded-xl p-6 flex flex-col gap-4 hover:border-primary/40 transition-colors duration-300"
              >
                <Quote className="w-6 h-6 text-primary/40 flex-shrink-0" />
                <p className="text-sm text-muted-foreground leading-relaxed flex-1 italic">
                  "{t.text}"
                </p>
                <div className="border-t border-border/50 pt-4">
                  <p className="text-sm font-semibold text-foreground">{t.name}</p>
                  <p className="text-xs text-primary font-mono mt-0.5">{t.role}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{t.school}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>
    </section>
  );
}
