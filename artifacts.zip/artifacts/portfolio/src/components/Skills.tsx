import { motion } from "framer-motion";

const skills = [
  { category: "Languages", items: ["JavaScript/TypeScript", "Python", "HTML/CSS", "Java", "C", "SQL", "Bash"] },
  { category: "Frameworks", items: ["React", "Next.js", "Node.js", "Express", "Tailwind CSS"] },
  { category: "Tools", items: ["Git", "Docker", "VS Code", "Linux", "Figma"] },
  { category: "Learning", items: ["Rust", "Go", "WebAssembly", "Kubernetes"] },
];

export function Skills() {
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.4 } }
  };

  return (
    <section id="skills" className="py-24 px-6 md:px-12 border-t border-border/50 bg-secondary/30">
      <div className="max-w-4xl mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.5 }}
          className="mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold font-sans flex items-center gap-4">
            <span className="text-primary font-mono text-xl md:text-2xl font-normal">02.</span> Arsenal
          </h2>
        </motion.div>

        <motion.div 
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-100px" }}
          className="grid sm:grid-cols-2 gap-8"
        >
          {skills.map((skillGroup, idx) => (
            <motion.div key={idx} variants={item} className="bg-card border border-border p-6 rounded-lg shadow-sm hover:border-primary/50 transition-colors">
              <h3 className="font-mono text-primary mb-4 text-lg border-b border-border/50 pb-2">{skillGroup.category}</h3>
              <ul className="space-y-2">
                {skillGroup.items.map((skill, sIdx) => (
                  <li key={sIdx} className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
                    <span className="text-primary text-xs">▹</span> {skill}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
