import { motion } from "framer-motion";
import { ArrowRight, Clock, Tag } from "lucide-react";
import { Link } from "wouter";
import { articles } from "@/data/articles";

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
};

export function Blog() {
  return (
    <section id="blog" className="py-24 px-6 md:px-12 border-t border-border/50">
      <div className="max-w-4xl mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-3 font-sans flex items-center gap-4">
            <span className="text-primary font-mono text-xl md:text-2xl font-normal">05.</span> Blog
          </h2>
          <p className="text-muted-foreground mb-12 text-lg">
            Des pensées, des retours d'expérience, et des trucs que j'apprends en chemin.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          className="space-y-6"
        >
          {articles.map((article) => (
            <motion.div key={article.id} variants={cardVariants}>
              <Link href={`/blog/${article.slug}`}>
                <article
                  data-testid={`card-blog-${article.id}`}
                  className="block group relative bg-secondary border border-border rounded-xl p-6 md:p-8 hover:border-primary/50 transition-all duration-300 cursor-pointer"
                >
                  <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex flex-wrap items-center gap-3 mb-3">
                        <span className="flex items-center gap-1 text-xs text-muted-foreground font-mono">
                          <Clock className="w-3 h-3" />
                          {article.readTime}
                        </span>
                        <span className="text-muted-foreground/40 text-xs">·</span>
                        <span className="text-xs text-muted-foreground font-mono">{article.date}</span>
                      </div>

                      <h3 className="text-lg md:text-xl font-semibold text-foreground mb-3 group-hover:text-primary transition-colors duration-200 leading-snug">
                        {article.title}
                      </h3>

                      <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                        {article.excerpt}
                      </p>

                      <div className="flex flex-wrap gap-2">
                        {article.tags.map((tag) => (
                          <span
                            key={tag}
                            className="inline-flex items-center gap-1 text-xs font-mono px-2.5 py-1 rounded-full bg-primary/10 text-primary border border-primary/20"
                          >
                            <Tag className="w-2.5 h-2.5" />
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="md:ml-6 flex-shrink-0 flex items-center text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all duration-200">
                      <ArrowRight className="w-5 h-5" />
                    </div>
                  </div>

                  <div className="absolute inset-0 rounded-xl bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
                </article>
              </Link>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4, duration: 0.5 }}
          className="mt-10 text-center"
        >
          <p className="text-sm font-mono text-muted-foreground/60">
            Plus d'articles à venir — je suis en train d'écrire.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
