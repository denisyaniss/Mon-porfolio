import { useState } from "react";
import { motion } from "framer-motion";
import { Github, Linkedin, Mail } from "lucide-react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  name: z.string().min(2, "Name is required"),
  email: z.string().email("Invalid email address"),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

type FormValues = z.infer<typeof formSchema>;

export function Contact() {
  const { toast } = useToast();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      message: "",
    },
  });

  const onSubmit = (data: FormValues) => {
    const subject = encodeURIComponent(`Portfolio Contact from ${data.name}`);
    const body = encodeURIComponent(`Name: ${data.name}\nEmail: ${data.email}\n\nMessage:\n${data.message}`);
    window.location.href = `mailto:officialdenis304@gmail.com?subject=${subject}&body=${body}`;
    
    toast({
      title: "Message composed",
      description: "Opening your default email client...",
    });
    
    form.reset();
  };

  return (
    <section id="contact" className="py-32 px-6 md:px-12 border-t border-border/50 relative">
      <div className="absolute inset-0 z-0 opacity-10 pointer-events-none">
        <div className="absolute bottom-0 inset-x-0 h-1/2 bg-gradient-to-t from-primary/20 to-transparent" />
      </div>
      
      <div className="max-w-2xl mx-auto w-full relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <div className="font-mono text-primary mb-4 text-sm tracking-widest uppercase">
            07. What's Next?
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6 font-sans">
            Get In Touch
          </h2>
          <p className="text-lg text-muted-foreground mb-10">
            Currently looking for new opportunities, internships, or interesting open-source projects to contribute to. Whether you have a question or just want to say hi, my inbox is always open.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="bg-card p-6 md:p-8 rounded-xl border border-border shadow-sm mb-12 text-left"
        >
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input placeholder="Your Name" {...field} data-testid="input-name" className="bg-background" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input placeholder="Your Email" type="email" {...field} data-testid="input-email" className="bg-background" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="message"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Textarea placeholder="Your Message" className="min-h-[120px] bg-background" {...field} data-testid="input-message" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full h-12 text-base font-medium" data-testid="button-submit">
                Send Message
              </Button>
            </form>
          </Form>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="text-center"
        >
          <div className="flex justify-center gap-6">
            <a href="https://github.com/denisyaniss" className="text-muted-foreground hover:text-primary transition-colors p-2" aria-label="GitHub">
              <Github className="w-6 h-6" />
            </a>
            <a href="https://www.linkedin.com/in/denis-yaniss-baa0aa3a6?utm_source=share_via&utm_content=profile&utm_medium=member_android" className="text-muted-foreground hover:text-primary transition-colors p-2" aria-label="LinkedIn">
              <Linkedin className="w-6 h-6" />
            </a>
            <a href="mailto: officialdenis304@gmail.com" className="text-muted-foreground hover:text-primary transition-colors p-2" aria-label="Email">
              <Mail className="w-6 h-6" />
            </a>
          </div>
          
          <div className="mt-12 font-mono text-xs text-muted-foreground/60">
            <p>Designed & Built by Denis Yaniss</p>
            <p className="mt-1">© {new Date().getFullYear()}</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
