import { Switch, Route } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { Hero } from "@/components/Hero";
import { About } from "@/components/About";
import { Skills } from "@/components/Skills";
import { Projects } from "@/components/Projects";
import { Contact } from "@/components/Contact";
import { Blog } from "@/components/Blog";
import { Learning } from "@/components/Learning";
import { Stats } from "@/components/Stats";
import { Testimonials } from "@/components/Testimonials";
import { Navbar } from "@/components/Navbar";
import { Loader } from "@/components/Loader";
import { ScrollToTop } from "@/components/ScrollToTop";
import BlogPost from "@/pages/BlogPost";
import CVPage from "@/pages/CVPage";
import { ThemeProvider } from "@/hooks/use-theme";
import { useState, useEffect } from "react";
import { AnimatePresence } from "framer-motion";

const queryClient = new QueryClient();

function Home() {
  return (
    <div className="bg-background min-h-screen text-foreground selection:bg-primary selection:text-primary-foreground">
      <Navbar />
      <main className="max-w-7xl mx-auto">
        <Hero />
        <About />
        <Stats />
        <Skills />
        <Projects />
        <Learning />
        <Blog />
        <Testimonials />
        <Contact />
      </main>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/blog/:slug" component={BlogPost} />
      <Route path="/cv" component={CVPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 1800);
    return () => clearTimeout(timer);
  }, []);

  return (
    <ThemeProvider defaultTheme="dark" storageKey="theme">
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <AnimatePresence>
            {loading && <Loader key="loader" />}
          </AnimatePresence>
          {!loading && <Router />}
          <ScrollToTop />
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
