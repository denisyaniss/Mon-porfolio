import type { Expense } from "@workspace/api-client-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { FileText, Receipt, ShoppingBag, Utensils, Bus, Home, Activity, Heart, BookOpen, Shirt, MoreHorizontal, Trash2, Loader2 } from "lucide-react";
import { useDeleteExpense, getGetExpensesQueryKey, getGetExpenseSummaryQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";

const CategoryIcon = ({ category, className }: { category: string, className?: string }) => {
  switch (category) {
    case "Alimentation": return <Utensils className={className} />;
    case "Transport": return <Bus className={className} />;
    case "Logement": return <Home className={className} />;
    case "Santé": return <Heart className={className} />;
    case "Loisirs": return <Activity className={className} />;
    case "Études": return <BookOpen className={className} />;
    case "Vêtements": return <Shirt className={className} />;
    default: return <MoreHorizontal className={className} />;
  }
};

const categoryColors: Record<string, string> = {
  "Alimentation": "bg-chart-1/10 text-chart-1 border-chart-1/20",
  "Transport": "bg-chart-2/10 text-chart-2 border-chart-2/20",
  "Logement": "bg-chart-3/10 text-chart-3 border-chart-3/20",
  "Santé": "bg-chart-4/10 text-chart-4 border-chart-4/20",
  "Loisirs": "bg-chart-5/10 text-chart-5 border-chart-5/20",
  "Études": "bg-primary/10 text-primary border-primary/20",
  "Vêtements": "bg-secondary/20 text-secondary-foreground border-secondary/30",
  "Autre": "bg-muted text-muted-foreground border-muted-foreground/20",
};

interface ExpenseListProps {
  expenses: Expense[];
  showDelete?: boolean;
}

export default function ExpenseList({ expenses, showDelete = false }: ExpenseListProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const deleteExpense = useDeleteExpense();

  const handleDelete = (id: number) => {
    deleteExpense.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetExpensesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetExpenseSummaryQueryKey() });
        toast({
          title: "Dépense supprimée",
          description: "La dépense a été retirée de l'historique.",
        });
      },
      onError: () => {
        toast({
          variant: "destructive",
          title: "Erreur",
          description: "Impossible de supprimer la dépense.",
        });
      }
    });
  };

  if (expenses.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground">
        <Receipt className="w-12 h-12 mb-4 opacity-20" />
        <p className="text-lg font-serif">Aucune dépense enregistrée</p>
        <p className="text-sm">Vos transactions apparaîtront ici.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {expenses.map((expense, index) => {
        const colorClass = categoryColors[expense.category] || categoryColors["Autre"];
        const isDeleting = deleteExpense.isPending && deleteExpense.variables?.id === expense.id;

        return (
          <div 
            key={expense.id}
            className="group flex items-center justify-between p-4 rounded-xl bg-card border border-border/50 shadow-sm transition-all duration-300 hover:shadow-md hover:border-primary/20 animate-in fade-in slide-in-from-bottom-4 fill-mode-both"
            style={{ animationDelay: `${index * 50}ms` }}
            data-testid={`expense-item-${expense.id}`}
          >
            <div className="flex items-center gap-4">
              <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center border", colorClass)}>
                <CategoryIcon category={expense.category} className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-medium text-foreground">{expense.label}</h4>
                <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                  <span className="capitalize">{format(new Date(expense.date), "d MMM yyyy", { locale: fr })}</span>
                  <span className="w-1 h-1 rounded-full bg-muted-foreground/30"></span>
                  <span>{expense.category}</span>
                  {expense.note && (
                    <>
                      <span className="w-1 h-1 rounded-full bg-muted-foreground/30"></span>
                      <span className="truncate max-w-[100px] sm:max-w-[200px]" title={expense.note}>
                        {expense.note}
                      </span>
                    </>
                  )}
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="font-serif font-semibold text-foreground text-right whitespace-nowrap">
                {Number(expense.amount).toFixed(2)} €
              </div>
              
              {showDelete && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive hover:bg-destructive/10 -mr-2"
                  onClick={() => handleDelete(expense.id)}
                  disabled={isDeleting || deleteExpense.isPending}
                  data-testid={`button-delete-expense-${expense.id}`}
                  title="Supprimer"
                >
                  {isDeleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                </Button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
