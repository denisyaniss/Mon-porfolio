import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useCreateExpense, getGetExpensesQueryKey, getGetExpenseSummaryQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Plus } from "lucide-react";
import { format } from "date-fns";

export const CATEGORIES = [
  "Alimentation",
  "Transport",
  "Logement",
  "Santé",
  "Loisirs",
  "Études",
  "Vêtements",
  "Autre"
] as const;

const formSchema = z.object({
  label: z.string().min(1, "Le libellé est requis"),
  amount: z.coerce.number().min(0.01, "Le montant doit être supérieur à 0"),
  category: z.string().min(1, "La catégorie est requise"),
  date: z.string().min(1, "La date est requise"),
  note: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export default function ExpenseForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const createExpense = useCreateExpense();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      label: "",
      amount: undefined as unknown as number,
      category: "",
      date: format(new Date(), "yyyy-MM-dd"),
      note: "",
    },
  });

  const onSubmit = (values: FormValues) => {
    createExpense.mutate({ data: values }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetExpensesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetExpenseSummaryQueryKey() });
        toast({
          title: "Dépense ajoutée",
          description: "Votre dépense a été enregistrée avec succès.",
        });
        form.reset({
          label: "",
          amount: undefined as unknown as number,
          category: "",
          date: format(new Date(), "yyyy-MM-dd"),
          note: "",
        });
      },
      onError: () => {
        toast({
          variant: "destructive",
          title: "Erreur",
          description: "Impossible d'ajouter la dépense.",
        });
      }
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5 animate-in slide-in-from-bottom-4 duration-500 fade-in fill-mode-both">
        <FormField
          control={form.control}
          name="label"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Libellé</FormLabel>
              <FormControl>
                <Input placeholder="Ex: Courses Carrefour" {...field} className="bg-background/50 focus:bg-background transition-colors" data-testid="input-label" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="amount"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Montant (€)</FormLabel>
                <FormControl>
                  <Input type="number" step="0.01" placeholder="0.00" {...field} className="bg-background/50 focus:bg-background transition-colors" data-testid="input-amount" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="date"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} className="bg-background/50 focus:bg-background transition-colors" data-testid="input-date" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="category"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Catégorie</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger className="bg-background/50 focus:bg-background transition-colors" data-testid="select-category">
                    <SelectValue placeholder="Choisir une catégorie" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {CATEGORIES.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="note"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Note (optionnel)</FormLabel>
              <FormControl>
                <Textarea placeholder="Détails supplémentaires..." {...field} className="resize-none bg-background/50 focus:bg-background transition-colors h-20" data-testid="textarea-note" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button 
          type="submit" 
          className="w-full font-medium" 
          disabled={createExpense.isPending}
          data-testid="button-submit-expense"
        >
          {createExpense.isPending ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Plus className="mr-2 h-4 w-4" />
          )}
          Ajouter la dépense
        </Button>
      </form>
    </Form>
  );
}
