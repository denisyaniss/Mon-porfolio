import { useGetExpenseSummary } from "@workspace/api-client-react";
import ExpenseForm from "@/components/expense-form";
import ExpenseList from "@/components/expense-list";
import SummaryChart from "@/components/summary-chart";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { ArrowRight, Wallet, TrendingUp } from "lucide-react";

export default function Dashboard() {
  const { data: summary, isLoading, isError } = useGetExpenseSummary();

  if (isError) {
    return (
      <div className="p-8 text-center bg-destructive/10 text-destructive rounded-xl border border-destructive/20 animate-in fade-in">
        Une erreur est survenue lors du chargement des données.
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl sm:text-4xl font-serif font-bold text-foreground tracking-tight">Bonjour, Denis.</h1>
        <p className="text-muted-foreground mt-2">Voici un aperçu de vos finances aujourd'hui.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Card className="bg-primary text-primary-foreground border-none shadow-lg shadow-primary/20 overflow-hidden relative">
              <div className="absolute right-0 top-0 w-32 h-32 bg-white/10 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none" />
              <CardHeader className="pb-2">
                <CardDescription className="text-primary-foreground/80 font-medium">Dépenses totales</CardDescription>
                <CardTitle className="text-4xl font-serif">
                  {isLoading ? <Skeleton className="h-10 w-32 bg-white/20" /> : `${Number(summary?.total ?? 0).toFixed(2)} €`}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-primary-foreground/90 mt-2 bg-black/10 w-fit px-2.5 py-1 rounded-full">
                  <TrendingUp className="w-3.5 h-3.5 mr-1.5" />
                  Mois en cours
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-sm border-border/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-serif">Répartition</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <Skeleton className="h-[200px] w-full rounded-xl" />
                ) : (
                  <SummaryChart data={summary?.byCategory || []} />
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-serif font-semibold text-foreground">Dépenses récentes</h2>
              <Link href="/history" className="text-sm text-primary hover:text-primary/80 font-medium flex items-center transition-colors">
                Voir tout <ArrowRight className="w-4 h-4 ml-1" />
              </Link>
            </div>
            
            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-20 w-full rounded-xl" />
                ))}
              </div>
            ) : (
              <ExpenseList expenses={summary?.recentExpenses || []} />
            )}
          </div>
        </div>

        <div className="lg:col-span-1">
          <div className="sticky top-24">
            <Card className="shadow-sm border-border/50 overflow-hidden">
              <div className="h-2 bg-gradient-to-r from-primary to-accent w-full" />
              <CardHeader>
                <CardTitle className="text-xl font-serif">Nouvelle dépense</CardTitle>
                <CardDescription>Ajoutez une transaction à votre journal.</CardDescription>
              </CardHeader>
              <CardContent>
                <ExpenseForm />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
