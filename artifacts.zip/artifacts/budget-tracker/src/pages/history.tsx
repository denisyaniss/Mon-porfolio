import { useGetExpenses } from "@workspace/api-client-react";
import ExpenseList from "@/components/expense-list";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Download, Search } from "lucide-react";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { format } from "date-fns";

export default function History() {
  const { data: expenses, isLoading, isError } = useGetExpenses();
  const [searchTerm, setSearchTerm] = useState("");

  const exportToCSV = () => {
    if (!expenses || expenses.length === 0) return;

    const headers = ["ID", "Libellé", "Montant", "Catégorie", "Date", "Note", "Créé le"];
    const rows = expenses.map(e => [
      e.id,
      `"${e.label.replace(/"/g, '""')}"`,
      Number(e.amount).toFixed(2),
      `"${e.category}"`,
      e.date,
      `"${(e.note || "").replace(/"/g, '""')}"`,
      e.createdAt
    ]);

    const csvContent = [
      headers.join(","),
      ...rows.map(r => r.join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `depenses_${format(new Date(), 'yyyy-MM-dd')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredExpenses = expenses?.filter(e => 
    e.label.toLowerCase().includes(searchTerm.toLowerCase()) || 
    e.category.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-serif font-bold text-foreground tracking-tight">Historique complet</h1>
          <p className="text-muted-foreground mt-1">Consultez et gérez toutes vos dépenses.</p>
        </div>
        
        <Button 
          onClick={exportToCSV} 
          variant="outline" 
          disabled={isLoading || !expenses || expenses.length === 0}
          className="bg-card shadow-sm font-medium"
          data-testid="button-export-csv"
        >
          <Download className="w-4 h-4 mr-2" />
          Exporter CSV
        </Button>
      </div>

      <Card className="shadow-sm border-border/50 border-t-4 border-t-primary overflow-hidden">
        <div className="p-4 border-b border-border/50 bg-muted/20">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Rechercher une dépense..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 bg-background"
              data-testid="input-search-history"
            />
          </div>
        </div>
        <CardContent className="p-0 sm:p-4">
          {isLoading ? (
            <div className="space-y-3 p-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-20 w-full rounded-xl" />
              ))}
            </div>
          ) : isError ? (
            <div className="p-8 text-center text-destructive">
              Erreur lors du chargement de l'historique.
            </div>
          ) : (
            <div className="p-4 sm:p-0">
              <ExpenseList expenses={filteredExpenses} showDelete={true} />
              
              {filteredExpenses.length === 0 && expenses && expenses.length > 0 && (
                <div className="text-center py-12 text-muted-foreground">
                  Aucun résultat pour "{searchTerm}"
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
