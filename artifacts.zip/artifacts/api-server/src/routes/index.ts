import { Router, type IRouter } from "express";
import healthRouter from "./health";
import testimonialsRouter from "./testimonials";
import expensesRouter from "./expenses";

const router: IRouter = Router();

router.use(healthRouter);
router.use(testimonialsRouter);
router.use(expensesRouter);

export default router;
