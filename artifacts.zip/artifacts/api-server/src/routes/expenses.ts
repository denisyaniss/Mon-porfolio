import { Router } from "express";
import { db } from "@workspace/db";
import { expensesTable } from "@workspace/db/schema";
import { CreateExpenseBody, DeleteExpenseParams } from "@workspace/api-zod";
import { eq, desc, sql } from "drizzle-orm";

const expensesRouter = Router();

expensesRouter.get("/expenses", async (req, res) => {
  try {
    const expenses = await db
      .select()
      .from(expensesTable)
      .orderBy(desc(expensesTable.date), desc(expensesTable.createdAt));
    res.json(expenses);
  } catch (err) {
    req.log.error(err, "Failed to fetch expenses");
    res.status(500).json({ error: "Erreur serveur" });
  }
});

expensesRouter.post("/expenses", async (req, res) => {
  const parsed = CreateExpenseBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Données invalides" });
    return;
  }
  try {
    const [created] = await db
      .insert(expensesTable)
      .values(parsed.data)
      .returning();
    res.status(201).json(created);
  } catch (err) {
    req.log.error(err, "Failed to create expense");
    res.status(500).json({ error: "Erreur serveur" });
  }
});

expensesRouter.get("/expenses/summary", async (req, res) => {
  try {
    const allExpenses = await db
      .select()
      .from(expensesTable)
      .orderBy(desc(expensesTable.date));

    const totalResult = await db
      .select({ total: sql<number>`COALESCE(SUM(${expensesTable.amount}::numeric), 0)` })
      .from(expensesTable);

    const byCategoryResult = await db
      .select({
        category: expensesTable.category,
        total: sql<number>`SUM(${expensesTable.amount}::numeric)`,
        count: sql<number>`COUNT(*)`,
      })
      .from(expensesTable)
      .groupBy(expensesTable.category)
      .orderBy(desc(sql`SUM(${expensesTable.amount}::numeric)`));

    res.json({
      total: Number(totalResult[0]?.total ?? 0),
      byCategory: byCategoryResult.map((r) => ({
        category: r.category,
        total: Number(r.total),
        count: Number(r.count),
      })),
      recentExpenses: allExpenses.slice(0, 5),
    });
  } catch (err) {
    req.log.error(err, "Failed to fetch expense summary");
    res.status(500).json({ error: "Erreur serveur" });
  }
});

expensesRouter.delete("/expenses/:id", async (req, res) => {
  const parsed = DeleteExpenseParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    res.status(400).json({ error: "ID invalide" });
    return;
  }
  try {
    const [deleted] = await db
      .delete(expensesTable)
      .where(eq(expensesTable.id, parsed.data.id))
      .returning();
    if (!deleted) {
      res.status(404).json({ error: "Dépense introuvable" });
      return;
    }
    res.json(deleted);
  } catch (err) {
    req.log.error(err, "Failed to delete expense");
    res.status(500).json({ error: "Erreur serveur" });
  }
});

export default expensesRouter;
