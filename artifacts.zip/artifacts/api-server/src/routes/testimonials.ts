import { Router } from "express";
import { db } from "@workspace/db";
import { testimonialsTable, insertTestimonialSchema } from "@workspace/db/schema";
import { eq } from "drizzle-orm";

const testimonialsRouter = Router();

testimonialsRouter.get("/testimonials", async (req, res) => {
  try {
    const testimonials = await db
      .select()
      .from(testimonialsTable)
      .where(eq(testimonialsTable.approved, true))
      .orderBy(testimonialsTable.createdAt);
    res.json(testimonials);
  } catch (err) {
    req.log.error(err, "Failed to fetch testimonials");
    res.status(500).json({ error: "Erreur serveur" });
  }
});

testimonialsRouter.post("/testimonials", async (req, res) => {
  const parsed = insertTestimonialSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Données invalides" });
    return;
  }
  try {
    const [created] = await db
      .insert(testimonialsTable)
      .values({ ...parsed.data, approved: true })
      .returning();
    res.status(201).json(created);
  } catch (err) {
    req.log.error(err, "Failed to create testimonial");
    res.status(500).json({ error: "Erreur serveur" });
  }
});

export default testimonialsRouter;
